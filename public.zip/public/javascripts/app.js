(function() {
  'use strict';

  var globals = typeof window === 'undefined' ? global : window;
  if (typeof globals.require === 'function') return;

  var modules = {};
  var cache = {};
  var has = ({}).hasOwnProperty;

  var aliases = {};

  var endsWith = function(str, suffix) {
    return str.indexOf(suffix, str.length - suffix.length) !== -1;
  };

  var unalias = function(alias, loaderPath) {
    var start = 0;
    if (loaderPath) {
      if (loaderPath.indexOf('components/' === 0)) {
        start = 'components/'.length;
      }
      if (loaderPath.indexOf('/', start) > 0) {
        loaderPath = loaderPath.substring(start, loaderPath.indexOf('/', start));
      }
    }
    var result = aliases[alias + '/index.js'] || aliases[loaderPath + '/deps/' + alias + '/index.js'];
    if (result) {
      return 'components/' + result.substring(0, result.length - '.js'.length);
    }
    return alias;
  };

  var expand = (function() {
    var reg = /^\.\.?(\/|$)/;
    return function(root, name) {
      var results = [], parts, part;
      parts = (reg.test(name) ? root + '/' + name : name).split('/');
      for (var i = 0, length = parts.length; i < length; i++) {
        part = parts[i];
        if (part === '..') {
          results.pop();
        } else if (part !== '.' && part !== '') {
          results.push(part);
        }
      }
      return results.join('/');
    };
  })();
  var dirname = function(path) {
    return path.split('/').slice(0, -1).join('/');
  };

  var localRequire = function(path) {
    return function(name) {
      var absolute = expand(dirname(path), name);
      return globals.require(absolute, path);
    };
  };

  var initModule = function(name, definition) {
    var module = {id: name, exports: {}};
    cache[name] = module;
    definition(module.exports, localRequire(name), module);
    return module.exports;
  };

  var require = function(name, loaderPath) {
    var path = expand(name, '.');
    if (loaderPath == null) loaderPath = '/';
    path = unalias(name, loaderPath);

    if (has.call(cache, path)) return cache[path].exports;
    if (has.call(modules, path)) return initModule(path, modules[path]);

    var dirIndex = expand(path, './index');
    if (has.call(cache, dirIndex)) return cache[dirIndex].exports;
    if (has.call(modules, dirIndex)) return initModule(dirIndex, modules[dirIndex]);

    throw new Error('Cannot find module "' + name + '" from '+ '"' + loaderPath + '"');
  };

  require.alias = function(from, to) {
    aliases[to] = from;
  };

  require.register = require.define = function(bundle, fn) {
    if (typeof bundle === 'object') {
      for (var key in bundle) {
        if (has.call(bundle, key)) {
          modules[key] = bundle[key];
        }
      }
    } else {
      modules[bundle] = fn;
    }
  };

  require.list = function() {
    var result = [];
    for (var item in modules) {
      if (has.call(modules, item)) {
        result.push(item);
      }
    }
    return result;
  };

  require.brunch = true;
  globals.require = require;
})();
require.register("initialize", function(exports, require, module) {
$(document).ready(function() {
  var el;
  $(".slick").slick({
    arrows: false,
    dots: true,
    autoplay: true,
    autoplaySpeed: 6000
  });
  el = $('.slick .item')[1];
  $(el).find('.background').addClass('visible');
  $('.slick').on('afterChange', function(event, slick, currentSlide) {
    $('.background').removeClass('visible');
    return $('.slick-active .background').addClass('visible');
  });
  $('.more').click(function() {
    return $('.invisible').addClass('visible-more');
  });
  $(".slick-2").slick({
    arrows: true,
    dots: false,
    autoplay: true,
    autoplaySpeed: 6000,
    centerMode: true,
    centerPadding: '0px',
    slidesToShow: 3
  });
  $('.block-map .close').click(function() {
    return $('.block-map').removeClass('visible-map');
  });
  $('.main-items .item').mouseenter(function() {
    $(this).find('.text').removeClass('visible');
    return $(this).find('img').addClass('visible');
  });
  return $('.main-items .item').mouseleave(function() {
    $(this).find('.text').addClass('visible');
    return $(this).find('img').removeClass('visible');
  });
});
});

;require.register("main", function(exports, require, module) {
$(document).ready(function(){
  function initialize() {
    var myLatlng = new google.maps.LatLng(47.226869, 39.732249);
    var styles = [
        {
          stylers: [
              { saturation: '-100' }
          ]
        }
      ];
    var mapOptions = {
      zoom: 18,
      center: myLatlng,
      disableDefaultUI: true,
      scrollwheel: false,
      styles: styles
    }
    
    var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

    var icon1 = "../images/Geo 1.svg";
    var icon2 = "../images/Geo 2.svg";

    

    var marker = new google.maps.Marker({
        position: myLatlng,
        icon: icon1,
        map: map,
    });

    google.maps.event.addListener(marker, 'mouseover', function() {
      marker.setIcon(icon2);
    });
    google.maps.event.addListener(marker, 'mouseout', function() {
        marker.setIcon(icon1);
    });
    google.maps.event.addListener(marker, 'click', function() {
      $('.block-map').addClass('visible-map');
    });
  }

  
  google.maps.event.addDomListener(window, 'load', initialize);

});








});


//# sourceMappingURL=app.js.map